﻿namespace WolfLive.Api.Delegates
{
	public delegate void ConnectionCarrier(IWolfClient client);
}
