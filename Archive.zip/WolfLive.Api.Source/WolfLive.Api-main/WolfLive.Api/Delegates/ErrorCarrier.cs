﻿using System;

namespace WolfLive.Api.Delegates
{
	public delegate void ErrorCarrier(IWolfClient client, Exception ex);
}
