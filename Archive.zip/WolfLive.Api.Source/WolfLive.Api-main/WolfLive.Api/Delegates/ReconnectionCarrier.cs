﻿namespace WolfLive.Api.Delegates
{
	public delegate void ReconnectionCarrier(IWolfClient client, int reconnectionCount);
}
