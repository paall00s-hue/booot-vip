﻿namespace WolfLive.Api.Delegates
{
	public delegate void ConnectionErrorCarrier(IWolfClient client, string error);
}
