﻿using System;

namespace WolfLive.Api.Commands
{
	[AttributeUsage(AttributeTargets.Method)]
	public class SetupAttribute : Attribute { }
}
