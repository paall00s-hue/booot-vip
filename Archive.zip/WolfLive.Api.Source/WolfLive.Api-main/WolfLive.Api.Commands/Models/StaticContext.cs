﻿namespace WolfLive.Api.Commands
{
	public class StaticContext : WolfContext { }
}
