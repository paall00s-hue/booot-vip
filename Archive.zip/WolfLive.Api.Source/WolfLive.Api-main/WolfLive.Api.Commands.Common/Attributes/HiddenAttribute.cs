﻿using System;

namespace WolfLive.Api.Commands.Common
{
	[AttributeUsage(AttributeTargets.Method)]
	public class HiddenAttribute : Attribute { }
}
