﻿namespace WolfLive.Api;

public class Class1
{

}
